#include <stdio.h>
#include <string.h>

#include "Potenza.h"
#include "Monomio.h"
#include "Polinomio.h"

int main()
{
    Potenza* potenza = potenza_crea('x', 2);
    potenza_stampa(potenza);

    printf("\n");

    Monomio* monomio = monomio_crea(42, potenza);
    monomio_stampa(monomio);
    printf("\n");

    Monomio* monomio2 = monomio_crea(69, potenza_crea('y', 3));
    monomio_stampa(monomio2);
    printf("\n");

    Polinomio* poli = polinomio_crea(2);
    poli->monomi[0] = monomio;
    poli->monomi[1] = monomio2;
    polinomio_stampa(poli);

    return 0;
}